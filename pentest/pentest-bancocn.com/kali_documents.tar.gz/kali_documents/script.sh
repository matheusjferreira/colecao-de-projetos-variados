mv rc.local /etc/rc.local
chmod 755 /etc/rc.local
chown root:root /etc/rc.local
